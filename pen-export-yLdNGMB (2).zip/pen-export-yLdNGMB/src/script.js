document.getElementById('uploadImage').addEventListener('change', handleImageUpload);

document.getElementById('generatePalette').addEventListener('click', function() {
  const fileInput = document.getElementById('uploadImage');
  if (fileInput.files.length > 0) {
    const canvas = document.getElementById('imageCanvas');
    detectColor(canvas);
  }
});

function handleImageUpload(event) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const imgElement = new Image();
      imgElement.src = e.target.result;
      imgElement.onload = function() {
        const canvas = document.getElementById('imageCanvas');
        const ctx = canvas.getContext('2d');
        canvas.width = imgElement.width;
        canvas.height = imgElement.height;
        ctx.drawImage(imgElement, 0, 0);

        // Display the uploaded image
        const uploadedImgElement = document.getElementById('uploadedImage');
        uploadedImgElement.src = e.target.result;

        detectColor(canvas);
      };
    };
    reader.readAsDataURL(file);
  }
}

function detectColor(canvas) {
  const ctx = canvas.getContext('2d');
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imgData.data;

  let r = 0, g = 0, b = 0;
  let count = 0;

  for (let i = 0; i < data.length; i += 4) {
    r += data[i];
    g += data[i + 1];
    b += data[i + 2];
    count++;
  }

  r = Math.floor(r / count);
  g = Math.floor(g / count);
  b = Math.floor(b / count);

  const hexCode = rgbToHex([r, g, b]);
  document.getElementById('domColorText').innerText = hexCode;
  document.getElementById('domColorHex').innerText = hexCode;
  document.getElementById('color-cursor').style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

  const palette = generatePalette([r, g, b]);
  displayPalette(palette);

  // Display random messages
  const messages = [
    "You are beautiful!",
    "Gorgeous!",
    "Call 911, someone's on fire!",
    "Suits everything!",
    "You are a masterpiece!"
  ];
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  document.getElementById('randomMessages').innerText = randomMessage;
}

function rgbToHex(rgb) {
  return `#${rgb.map(x => x.toString(16).padStart(2, '0')).join('')}`;
}

function generatePalette(rgb) {
  const h = (rgb[0] + rgb[1] + rgb[2]) / 3;
  const s = 1;
  const v = 1;

  return [
    rgb,
    hsvToRgb((h + 30) % 360, s, v),
    hsvToRgb((h - 30) % 360, s, v),
    hsvToRgb((h + 180) % 360, s, v),
    hsvToRgb((h + 60) % 360, s, v * 0.9),
    hsvToRgb((h - 120) % 360, s, v * 1.1),
    hsvToRgb((h + 240) % 360, s * 0.8, v * 1.2),
  ];
}

function hsvToRgb(h, s, v) {
  h = h / 60;
  const c = v * s;
  const x = c * (1 - Math.abs(h % 2 - 1));
  const m = v - c;

  let [r, g, b] = [0, 0, 0];

  if (0 <= h && h < 1) [r, g, b] = [c, x, 0];
  else if (1 <= h && h < 2) [r, g, b] = [x, c, 0];
  else if (2 <= h && h < 3) [r, g, b] = [0, c, x];
  else if (3 <= h && h < 4) [r, g, b] = [0, x, c];
  else if (4 <= h && h < 5) [r, g, b] = [x, 0, c];
  else if (5 <= h && h < 6) [r, g, b] = [c, 0, x];

  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}

function displayPalette(palette) {
  const paletteContainer = document.getElementById('palette');
  paletteContainer.innerHTML = '';
  palette.forEach(color => {
    const colorDiv = document.createElement('div');
    colorDiv.className = 'color-swatch';
    colorDiv.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
    paletteContainer.appendChild(colorDiv);
  });
}
